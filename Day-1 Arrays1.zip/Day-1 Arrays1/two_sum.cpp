// class Solution {
// public:
//     vector<int> twoSum(vector<int>& nums, int target) {
//         vector<int>result;
//         for(int i=0;i<nums.size()-1;i++){
//             int num=target-nums[i];
//             for(int j=i+1;j<nums.size();j++){
//                 if(nums[j]==num){
                    
//                     result.push_back(i);
//                     result.push_back(j);
//                     break;
                    
//                 }
//             }
//         }
//         return result;
//     }
// };


class Solution {
public:
    vector<int> twoSum(vector<int>& nums, int target) {
        vector<int> ans;
        unordered_map<int,int> umap;
        
        for(int i=0;i<nums.size();i++){
            if(umap.find(target-nums[i])!=umap.end()){
                    auto key=umap.find(target-nums[i]);
                    ans.push_back(key->second);
                    ans.push_back(i);
                    return ans;
                }
            else{
                umap.insert(make_pair(nums[i],i));
            }
                
        }
        return ans;
    }
    };