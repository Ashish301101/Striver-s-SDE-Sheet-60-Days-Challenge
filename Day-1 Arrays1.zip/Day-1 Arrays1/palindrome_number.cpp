class Solution {
public:
    bool isPalindrome(int x) {
        long long int num=0;
        long long int inputno=x;
      while(x>0){
          num=num*10;
          num=num+(x%10);
          x=x/10;
      }
        return num==inputno;
        
        
    }
};