class Solution {
public:
    void sortColors(vector<int>& nums) {
        
        
        int f=0,s=0,t=0;
        
        for(int i=0;i<nums.size();i++){
            if(nums[i]==0)
                    f++;
            else if(nums[i]==1)
                s++;
            else
                t++;
        }
        int j=0;
        for(j=0;j<f;j++){
            nums[j]=0;
        }
        for(j=f;j<f+s;j++){
            nums[j]=1;
            
        }
        for(j=f+s;j<f+s+t;j++){
            nums[j]=2;
        }
        
        for(int i=0;i<f+s+t;i++){
            cout<<nums[i];
        }
        
    }
};