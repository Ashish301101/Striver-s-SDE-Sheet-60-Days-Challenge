class Solution {
public:
    int findDuplicate(vector<int>& nums) {
        unordered_map<int,int>umap;
        for(int i=0;i<nums.size();i++){
            if(umap.find(nums[i])!=umap.end()){
                auto key=umap.find(nums[i]);
                key->second++;
            }
            else{
                umap.insert(make_pair(nums[i],0));
            }
        }
                for(auto itr=umap.begin();itr!=umap.end();itr++){
                    int secondvalue=itr->second;
                    if(secondvalue >0)
                            return itr->first;
                    else
                            continue;
                            
                }
        return 0;
            }
        
    };